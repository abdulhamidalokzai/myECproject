# shop_app
App made with Flutter

Project: Shop List.

Shop List app from the Maximilian Schwarzmüller's Udemy course
